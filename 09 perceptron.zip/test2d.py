import numpy as np
from perceptron import Perceptron

X = np.array([
    [0.5, 1.0],
    [1.0, 0.5],
    [1.5, 2.0],
    [2.0, 1.5],
    [0.1, 0.2],
    [0.2, 0.1]
])

y = np.array([0, 0, 1, 1, 0, 0])
